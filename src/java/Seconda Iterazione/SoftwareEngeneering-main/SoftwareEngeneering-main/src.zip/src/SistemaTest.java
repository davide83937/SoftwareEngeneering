import org.junit.jupiter.api.Test;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.time.LocalDate;
import java.util.Timer;

import static org.junit.jupiter.api.Assertions.*;

class SistemaTest {

    DatabaseConnection dbConnection = null;
    Sistema sistema = Sistema.getInstance();

    SistemaTest() throws SQLException {
    }

    @Test
    void inserisciDatiPrenotazione() {

    }

    @Test
    void terminaPrenotazione() throws SQLException, InterruptedException {

    }

    @Test
    void getListaAule() {
    }

    @Test
    void load() {
    }

    @Test
    void load_disponibilita() {
    }

    @Test
    void getInstance() {
    }

    @Test
    void inserimentoDatiAula() {
    }

    @Test
    void terminaInserimentoAula() {
    }

    @Test
    void inserimentoDatiTavolo() {

    }

    @Test
    void terminaInserimentoTavolo() {
    }


}