import javax.swing.*;

public class Prova2 {
    private JButton nuovoTavoloButton;
    private JPanel panel1;
    private JButton nuovaAulaButton;
    private JButton nuovaPrenotazioneButton;

    public JPanel getMainPanel() {
        return panel1;
    }
}
